# [Call-To-Action](https://imatechnophile.github.io/Call-To-Action/) ```Click here to see this webpage```
  ## Simple Website Landing page animation:
  
 *Use my blog [Simple Home Page](https://medium.com/@cjsaravana95/simple-home-page-94863404d013) to get more knowledge about this repo* 

1. *landing page*:
![lading_page](https://user-images.githubusercontent.com/35361302/40711123-094a9dda-6418-11e8-8b38-290abf5e289f.png)
2. *Footer*:
![footer](https://user-images.githubusercontent.com/35361302/40711154-1f2c2056-6418-11e8-8c6c-898c3bc24c7d.png)


